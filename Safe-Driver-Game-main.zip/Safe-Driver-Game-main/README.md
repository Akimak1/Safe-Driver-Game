# Safe-Driver-Game
A videogame about driving very safe.

Instructions:
-Use ARROW KEYS to control the vehicle. 
-Pause the game by pressing the ESC button. 

Objective:
Deliver 4 packages to houses troughout the city. 
Avoid hitting obstacles for it lowers your points. 
Do side quests indicated in the in-game instructions. 

Additional information:
There are comments in the scripts to better understand the function of each variable and script. Scripts are titled properly to not be confusing once editing. Key variables are public so that they are easily editable in the Unity attributes editor. The collision system is based on tags. Each obstacle has a tag that can be easily changed in the Unity Editor once the collision occurs certain functions will be called to increment or deduct points accordingly. Colliders are polygonal so that objects are accurately represented. 
